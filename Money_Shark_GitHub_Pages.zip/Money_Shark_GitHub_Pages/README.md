# Money Shark Studio

Browser-based content studio with ten tools. The dashboard and offline draft generators run in JavaScript. Groq text generation requires your own API key entered in the app's AI settings; optional Puter media requests depend on provider availability, permission, and billing.

## GitHub Pages
1. Create a **private** repository for source development. Note: GitHub Pages on a free personal account generally requires a public repository; do **not** publish secrets or personal content.
2. Upload `index.html` to the repository root.
3. Repository Settings → Pages → Build and deployment → Deploy from a branch → `main` / `/ (root)` → Save.
4. Once deployed, browse the Pages HTTPS URL in Chrome.

Security: Never commit API keys. This HTML file contains no Groq API key. Browser-side API calls expose entered keys to the browser environment; production apps should use a backend proxy to protect secrets.
